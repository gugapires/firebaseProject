var firebaseConfig = {
    apiKey: "AIzaSyDtJAUXlS3jz5YWrSFUWIEh-SMgiglH-n0",
    authDomain: "todo-list-d6f78.firebaseapp.com",
    projectId: "todo-list-d6f78",
    storageBucket: "todo-list-d6f78.appspot.com",
    messagingSenderId: "167389201140",
    appId: "1:167389201140:web:768a141129a4da077254a1",
  }
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);